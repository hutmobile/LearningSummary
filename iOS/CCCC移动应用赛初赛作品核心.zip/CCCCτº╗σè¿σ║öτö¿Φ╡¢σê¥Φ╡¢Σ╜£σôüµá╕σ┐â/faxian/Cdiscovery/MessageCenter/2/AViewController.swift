//p
//  Created by adong666666 on 2018/5/26. Copyright © 2018年 adong666666. All rights reserved.

import UIKit
import Toaster

class AViewController: UIViewController {
    var imgView: UIImageView = {
        let v = UIImageView(image: UIImage(named: "22.jpg"))
        v.frame = CGRect(x: 0.fitScreen, y: 0.fitHeight, width: 414.fitScreen, height: 737.fitHeight)
        return v
    }()
    var Label: PowerLabel = {
        let label = PowerLabel(frame: CGRect(x: 160.fitScreen, y: 25.fitHeight, width: 100.fitScreen, height: 40.fitHeight))
        label.text = "详情"
        label.alpha = 0.8
        label.font = UIFont (name: "Arial", size: 24)
        label.textColor = UIColor.magenta
        return label
    }()
    var Label1: PowerLabel = {
        let label = PowerLabel(frame: CGRect(x: 10.fitScreen, y: 80.fitHeight, width: 400.fitScreen, height: 60.fitHeight))
        label.text = "恭喜恭喜,你已成功报名“了然于心”了!"
        label.alpha = 0.8
        label.font = UIFont (name: "Arial", size: 22)
        label.textColor = UIColor.red
        return label
    }()

    var Label3: PowerLabel = {
        let label = PowerLabel(frame: CGRect(x: 20.fitScreen, y: 150.fitHeight, width: 400.fitScreen, height: 60.fitHeight))
        label.text = "接下来请不忘初心"
        label.alpha = 0.8
        label.font = UIFont (name: "Arial", size: 22)
        label.textColor = UIColor.purple
        return label
    }()
    var Label4: PowerLabel = {
        let label = PowerLabel(frame: CGRect(x: 10.fitScreen, y: 200.fitHeight, width: 400.fitScreen, height: 60.fitHeight))
        label.text = "保持着参与活动的热情和信念"
        label.alpha = 0.8
        label.font = UIFont (name: "Arial", size: 22)
        label.textColor = UIColor.blue
        return label
    }()
    var Label5: PowerLabel = {
        let label = PowerLabel(frame: CGRect(x: 10.fitScreen, y: 250.fitHeight, width: 400.fitScreen, height: 60.fitHeight))
        label.text = "预祝你能快乐地陪大家度过此次活动"
        label.alpha = 0.8
        label.font = UIFont (name: "Arial", size: 22)
        label.textColor = UIColor.cyan
        return label
    }()
    var Label6: PowerLabel = {
        let label = PowerLabel(frame: CGRect(x: 10.fitScreen, y: 300.fitHeight, width: 400.fitScreen, height: 60.fitHeight))
        label.text = "并拥有属于自己的美好经历"
        label.alpha = 0.8
        label.font = UIFont (name: "Arial", size: 22)
        label.textColor = UIColor.green
        return label
    }()
    var Label7: PowerLabel = {
        let label = PowerLabel(frame: CGRect(x: 10.fitScreen, y: 350.fitHeight, width: 400.fitScreen, height: 60.fitHeight))
        label.text = "在活动中有所收获"
        label.alpha = 0.8
        label.font = UIFont (name: "Arial", size: 22)
        label.textColor = UIColor.yellow
        return label
    }()
    var Label8: PowerLabel = {
        let label = PowerLabel(frame: CGRect(x: 10.fitScreen, y: 400.fitHeight, width: 400.fitScreen, height: 60.fitHeight))
        label.text = "最后"
        label.alpha = 0.8
        label.font = UIFont (name: "Arial", size: 22)
        label.textColor = UIColor.orange
        return label
    }()
    var Label9: PowerLabel = {
        let label = PowerLabel(frame: CGRect(x: 10.fitScreen, y: 450.fitHeight, width: 400.fitScreen, height: 60.fitHeight))
        label.text = "期待在美好的时间和地点相约美好的你"
        label.alpha = 0.8
        label.font = UIFont (name: "Arial", size: 22)
        label.textColor = UIColor.red
        return label
    }()
    var btn1: UIButton = {
        let bt1 = UIButton(type: UIButtonType.roundedRect)
        bt1.frame = CGRect(x: 0.fitScreen, y: 30.fitHeight, width: 25.fitScreen, height: 25.fitHeight)
        bt1.setBackgroundImage(UIImage(named: "b11"), for: UIControlState())
        bt1.setTitle(" ", for: UIControlState())
        bt1.setTitleColor(UIColor.white, for: UIControlState())
        bt1.titleLabel?.font = UIFont(name: "Arial", size: 24)
        bt1.addTarget(self, action: #selector(ViewController.buttonTap(_:)), for: UIControlEvents.touchUpInside)
        return bt1
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        self.view.addSubview(imgView)
        self.view.addSubview(Label)
        self.view.addSubview(Label1)
        self.view.addSubview(Label3)
        self.view.addSubview(Label4)
        self.view.addSubview(Label5)
        self.view.addSubview(Label6)
        self.view.addSubview(Label7)
        self.view.addSubview(Label8)
        self.view.addSubview(Label9)
        self.view.addSubview(btn1)
        ToastView.appearance().backgroundColor = UIColor.lightText
        ToastView.appearance().textColor = UIColor.magenta
        ToastView.appearance().font = UIFont(name: "Arial", size: 24)
        ToastView.appearance().textInsets = UIEdgeInsets(top: 16, left: 20, bottom: 16, right: 20)
        ToastView.appearance().cornerRadius = 30
        ToastView.appearance().bottomOffsetPortrait = 120
        Toast(text: "小伙伴们一定要准时参加活动哟，我们不见不散！").show()
    }
    @objc func buttonTap(_ Button: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }

}
