/*import UIKit
import CVClendar

class SeventeenthViewController: UIViewController {
    var imgView: UIImageView = {
        let v = UIImageView(image: UIImage(named:"23.jpg"))
        v.frame = CGRect(x:0.fitScreen, y:0.fitScreen, width:414.fitScreen, height:737.fitScreen)
        return v
    }()
    var menuView : CVCalendarMenuView!
    var calendarView : CVCalendarView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.view.backgroundColor = UIColor(red: 239.0/255, green: 239.0/255, blue: 239.0/255, alpha: 1.0)
        
        self.menuView = CVCalendarMenuView(frame: CGRect(x: 20, y: 40, width: 280, height: 15))
        
        self.calendarView = CVCalendarView(frame: CGRect(x: 20, y: 60, width: 280, height: 320))
        
        self.calendarView.calendarAppearanceDelegate = self
        self.calendarView.calendarDelegate = self
        self.calendarView.animatorDelegate = self
        
        self.menuView.menuViewDelegate = self
        self.view.addSubview(imgView)
        self.view.addSubview(menuView)
        self.view.addSubview(calendarView)
        
    }
    
    override func viewDidLayoutSubviews()
    {
        super.viewDidLayoutSubviews()
        
        self.menuView.commitMenuViewUpdate()
        self.calendarView.commitCalendarViewUpdate()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ViewController: CVCalendarViewDelegate, CVCalendarMenuViewDelegate
{
    func presentationMode() -> CalendarMode
    {
        return .monthView
    }
    
    func firstWeekday() -> Weekday {
        return .sunday
    }
    
    func dayOfWeekTextColor(by weekday: Weekday) -> UIColor
    {
        return weekday == .sunday ? UIColor.red : UIColor.black
    }
    
    func shouldShowWeekdaysOut() -> Bool
    {
        return true
    }
    
    func shouldAnimateResizing() -> Bool
    {
        return true
    }
    
    private func shouldSelectDayView(dayView: DayView) -> Bool
    {
        return arc4random_uniform(3) == 0 ? true : false
    }
    
    func didSelectDayView(_ dayView: CVCalendarDayView, animationDidFinish: Bool)
    {
        print("\(dayView.date.commonDescription) is selected!")
    }
    
    func topMarker(shouldDisplayOnDayView dayView: CVCalendarDayView) -> Bool
    {
        return true
    }
    
    func dotMarker(shouldShowOnDayView dayView: CVCalendarDayView) -> Bool
    {
        let day = dayView.date.day
        let randomDay = Int(arc4random_uniform(31))
        if day == randomDay
        {
            return true
        }
        
        return false
    }
    
    func dotMarker(colorOnDayView dayView: CVCalendarDayView) -> [UIColor]
    {
        let red = CGFloat(arc4random_uniform(600) / 255)
        let green = CGFloat(arc4random_uniform(600) / 255)
        let blue = CGFloat(arc4random_uniform(600) / 255)
        
        let color = UIColor(red: red, green: green, blue: blue, alpha: 1)
        
        let numberOfDots = Int(arc4random_uniform(3) + 1)
        switch(numberOfDots)
        {
        case 2:
            return [color, color]
        case 3:
            return [color, color, color]
        default:
            return [color]
        }
    }
    
    func dotMarker(shouldMoveOnHighlightingOnDayView dayView: CVCalendarDayView) -> Bool
    {
        return true
    }
    
    func dotMarker(sizeOnDayView dayView: DayView) -> CGFloat
    {
        return 13
    }
    
    func weekdaySymbolType() -> WeekdaySymbolType
    {
        return .short
    }
    
    func selectionViewPath() -> ((CGRect) -> (UIBezierPath))
    {
        return { UIBezierPath(rect: CGRect(x: 0, y: 0, width: $0.width, height: $0.height)) }
    }
    
    func shouldShowCustomSingleSelection() -> Bool
    {
        return false
    }
    
    func preliminaryView(viewOnDayView dayView: DayView) -> UIView
    {
        let circleView = CVAuxiliaryView(dayView: dayView, rect: dayView.frame, shape: CVShape.circle)
        circleView.fillColor = .colorFromCode(0xCCCCCC)
        return circleView
    }
    
    func preliminaryView(shouldDisplayOnDayView dayView: DayView) -> Bool
    {
        if (dayView.isCurrentDay)
        {
            return true
        }
        return false
    }
    
    func supplementaryView(viewOnDayView dayView: DayView) -> UIView
    {
        let π = M_2_PI
        
        let ringSpacing: CGFloat = 3.0
        let ringInsetWidth: CGFloat = 1.0
        let ringVerticalOffset: CGFloat = 1.0
        var ringLayer: CAShapeLayer!
        let ringLineWidth: CGFloat = 1.0
        let ringLineColour: UIColor = UIColor.purple
        
        let newView = UIView(frame: dayView.bounds)
        
        let diameter: CGFloat = (newView.bounds.width) - ringSpacing
        let radius: CGFloat = diameter / 2.0
        
        let rect = CGRect(x: newView.frame.midX-radius, y: newView.frame.midY-radius-ringVerticalOffset, width: diameter, height: diameter)
        
        ringLayer = CAShapeLayer()
        newView.layer.addSublayer(ringLayer)
        
        ringLayer.fillColor = nil
        ringLayer.lineWidth = ringLineWidth
        ringLayer.strokeColor = ringLineColour.cgColor
        
        let ringLineWidthInset: CGFloat = CGFloat(ringLineWidth/2.0) + ringInsetWidth
        let ringRect: CGRect = rect.insetBy(dx: ringLineWidthInset, dy: ringLineWidthInset)
        let centrePoint: CGPoint = CGPoint(x: ringRect.midX, y: ringRect.midY)
        let startAngle: CGFloat = CGFloat(-π/2.0)
        let endAngle: CGFloat = CGFloat(π * 2.0) + startAngle
        let ringPath: UIBezierPath = UIBezierPath(arcCenter: centrePoint, radius: ringRect.width/2.0, startAngle: startAngle, endAngle: endAngle, clockwise: true)
        
        ringLayer.path = ringPath.cgPath
        ringLayer.frame = newView.layer.bounds
        
        return newView
    }
    
    func supplementaryView(shouldDisplayOnDayView dayView: DayView) -> Bool
    {
        /*if (dayView.date.weekDay == Weekday.friday)
        {
            return true
        }*/
        
        return false
    }
    
    func dayOfWeekTextColor() -> UIColor
    {
        return UIColor.black
    }
    
    func dayOfWeekBackGroundColor() -> UIColor
    {
        return UIColor.clear
    }
}*/
