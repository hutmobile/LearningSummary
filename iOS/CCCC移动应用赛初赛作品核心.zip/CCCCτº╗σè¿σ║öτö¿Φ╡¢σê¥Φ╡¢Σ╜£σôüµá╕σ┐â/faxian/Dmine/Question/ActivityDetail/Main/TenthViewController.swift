//k
//  Created by adong666666 on 2018/5/26.  Copyright © 2018年 adong666666. All rights reserved.

import UIKit
import Charts

class TenthViewController: UIViewController {
    var imgView: UIImageView = {
        let v = UIImageView(image: UIImage(named: "2"))
        v.frame = CGRect(x: 0.fitScreen, y: 0.fitHeight, width: 414.fitScreen, height: 737.fitHeight)
        v.alpha = 0.4
        return v
    }()
    var btn: UIButton = {
        let bt1 = UIButton(type: UIButtonType.roundedRect)
        bt1.frame = CGRect(x: 0.fitScreen, y: 30.fitHeight, width: 20.fitScreen, height: 25.fitHeight)
        bt1.setBackgroundImage(UIImage(named: "14"), for: UIControlState())
        bt1.setTitle(" ", for: UIControlState())
        bt1.setTitleColor(UIColor.white, for: UIControlState())
        bt1.titleLabel?.font = UIFont(name: "Arial", size: 24)
        bt1.addTarget(self, action: #selector(ViewController.buttonTap(_:)), for: UIControlEvents.touchUpInside)
        return bt1
    }()
    var btn2: PowerButton = {
        let bt = PowerButton(type: UIButtonType.roundedRect)
        bt.frame = CGRect (x: 0.fitScreen, y: 280.fitHeight, width: 414.fitScreen, height: 50.fitHeight)
        bt.backgroundColor = UIColor.clear
        bt.setTitle("活动明细一", for: UIControlState())
        bt.titleLabel?.font = UIFont(name: "Arial", size: 23)
        bt.addTarget(self, action: #selector(ViewController.buttonTap2(_:)),
                     for: UIControlEvents.touchUpInside)
        bt.layer.masksToBounds = true
        bt.layer.cornerRadius = 16
        bt.layer.borderWidth = 2
        bt.layer.borderColor = UIColor.clear.cgColor
        bt.setTitleColor(UIColor.red, for: UIControlState())
        return bt
    }()
    var btn1: PowerButton = {
        let bt1 = PowerButton(type: UIButtonType.roundedRect)
        bt1.frame = CGRect (x: 0.fitScreen, y: 380.fitHeight, width: 414.fitScreen, height: 50.fitHeight)
        bt1.backgroundColor = UIColor.clear
        bt1.setTitle("活动明细二", for: UIControlState())
        bt1.titleLabel?.font = UIFont(name: "Arial", size: 23)
        bt1.addTarget(self, action: #selector(ViewController.buttonTap1(_:)), for: UIControlEvents.touchUpInside)
        bt1.layer.masksToBounds = true
        bt1.layer.cornerRadius = 16
        bt1.layer.borderWidth = 2
        bt1.layer.borderColor = UIColor.clear.cgColor
        bt1.setTitleColor(UIColor.orange, for: UIControlState())
        return bt1
    }()
    var Label: PowerLabel = {
        let label = PowerLabel(frame: CGRect(x: 160.fitScreen, y: 25.fitHeight, width: 100.fitScreen, height: 40.fitHeight))
        label.text = "活动明细"
        label.alpha = 0.8
        label.font = UIFont (name: "Arial", size: 24)
        label.textColor = UIColor.magenta
        return label
    }()
    var Label2: PowerLabel = {
        let label = PowerLabel(frame: CGRect(x: 0.fitScreen, y: 180.fitHeight, width: 200.fitScreen, height: 40.fitHeight))
        label.text = "12月份～5月份："
        label.alpha = 0.8
        label.font = UIFont (name: "Arial", size: 24)
        label.textColor = UIColor.green
        return label
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        self.view.addSubview(imgView)
        self.view.addSubview(btn)
        self.view.addSubview(btn1)
        self.view.addSubview(btn2)
        self.view.addSubview(Label)
        self.view.addSubview(Label2)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }
    @objc func buttonTap(_ button: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    @objc func buttonTap2(_ button: UIButton) {
        self.present(FifthViewController(), animated: true, completion: nil)
    }
    @objc func buttonTap1(_ button: UIButton) {
        self.present(TwentiethViewController(), animated: true, completion: nil)
    }
}
