//  Created by adong666666 on 2018/5/30.  Copyright © 2018年 adong666666. All rights reserved.

import UIKit
class AnimationController: UIViewController {
    var btn = { () -> UIButton in
        let bt = UIButton(frame: CGRect(x: 190.fitScreen, y: 600.fitHeight, width: 60.fitScreen, height: 60.fitHeight))
        bt.backgroundColor = UIColor.lightText
        bt.layer.cornerRadius = 30
        bt.setTitleColor(UIColor.orange, for: .normal)
        bt.setTitle("X", for: .normal)
        bt.titleLabel?.font = UIFont(name: "Arial", size: 28)
        bt.addTarget(self, action: #selector(AnimationController.dismissViewController(_:)), for: .touchUpInside)
        return bt
    }()
    var imgView: UIImageView = {
        let v = UIImageView(image: UIImage(named: "50.jpg"))
        v.frame = CGRect(x: 0.fitScreen, y: 0.fitHeight, width: 414.fitScreen, height: 737.fitHeight)
        v.alpha = 0.4
        return v
    }()
    var btn2: PowerButton = {
        let bt = PowerButton(type: UIButtonType.roundedRect)
        bt.frame = CGRect (x: 140.fitScreen, y: 120.fitHeight, width: 160.fitScreen, height: 250.fitHeight)
        let image3 = UIImage(named: "0.jpg")
        bt.setBackgroundImage(image3, for: UIControlState())
        bt.setTitle(" ", for: UIControlState())
        bt.setTitleColor(UIColor.white, for: UIControlState())
        bt.titleLabel?.font = UIFont(name: "Arial", size: 24)
        bt.addTarget(self, action: #selector(ViewController.buttonTap(_:)), for: UIControlEvents.touchUpInside)
        bt.alpha = 1
        return bt
    }()
    var btn4: PowerButton = {
        let bt4 = PowerButton(type: UIButtonType.roundedRect)
        bt4.frame = CGRect (x: 95.fitScreen, y: 420.fitHeight, width: 250.fitScreen, height: 30.fitHeight)
        bt4.backgroundColor = UIColor.clear
        bt4.setTitle("享受生活", for: UIControlState())
        bt4.setTitleColor(UIColor.lightGray, for: UIControlState())
        bt4.titleLabel?.font = UIFont(name: "Arial", size: 23)
        bt4.addTarget(self, action: #selector(ViewController.buttonTap3(_:)), for: UIControlEvents.touchUpInside)
        bt4.layer.masksToBounds = true
        bt4.layer.cornerRadius = 16
        bt4.layer.borderWidth = 2
        bt4.layer.borderColor = UIColor.clear.cgColor
        return bt4
    }()
    var Label: PowerLabel = {
        let label = PowerLabel(frame: CGRect(x: 95.fitScreen, y: 460.fitHeight, width: 250.fitScreen, height: 30.fitHeight))
        label.text = "分数 ： 24分"
        label.alpha = 0.8
        label.font = UIFont (name: "Arial", size: 24)
        label.textColor = UIColor.green
        return label
    }()
    var Label2: PowerLabel = {
        let label = PowerLabel(frame: CGRect(x: 95.fitScreen, y: 500.fitHeight, width: 250.fitScreen, height: 30.fitHeight))
        label.text = "成就数 ： 12"
        label.alpha = 0.8
        label.font = UIFont (name: "Arial", size: 24)
        label.textColor = UIColor.green
        return label
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        self.view.addSubview(btn2)
        self.view.addSubview(imgView)
        self.view.addSubview(btn)
        self.view.addSubview(btn4)
        self.view.addSubview(Label)
        self.view.addSubview(Label2)
    }

    @objc func dismissViewController(_ btn: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    @objc func buttonTap(_ button: UIButton) {

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
