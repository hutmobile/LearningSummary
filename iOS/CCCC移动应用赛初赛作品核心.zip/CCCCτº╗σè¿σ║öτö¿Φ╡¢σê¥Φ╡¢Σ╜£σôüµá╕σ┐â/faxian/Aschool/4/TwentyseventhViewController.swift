//
//  TwentyseventhViewController.swift
//  faxian
//
//  Created by adong666666 on 2018/6/2.
//  Copyright © 2018年 adong666666. All rights reserved.

import UIKit
import PagingMenuController
class TwentyseventhViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }

}
