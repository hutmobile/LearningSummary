//e
//  Created by adong666666 on 2018/5/24. Copyright © 2018年 adong666666. All rights reserved.
//这里写了五个页面
/*
import UIKit
import Toaster
import BubbleTransition
import PagingMenuController

private struct PagingMenuOptions: PagingMenuControllerCustomizable
{
    fileprivate var componentType: ComponentType
    {
        return .all(menuOptions: MenuOptions(), pagingControllers: pagingControllers)
    }
    fileprivate var pagingControllers: [UIViewController]
    {
        let viewController1 = SixthViewController()
        let viewController2 = TwentyfifthViewController()
        let viewController3 = TwentysixthViewController()
        let viewController4 = TwentyseventhViewController()
        
        return [viewController1, viewController2, viewController3, viewController4]
    }
    fileprivate struct MenuOptions: MenuViewCustomizable
    {
        var displayMode: MenuDisplayMode
        {
            return .segmentedControl
        }
        //var focusMode: MenuFocusMode
        //{
           // return .roundRect(radius: 12, horizontalPadding: 8, verticalPadding: 8, selectedColor: UIColor.orange)
        //}
        //var focusMode: MenuFocusMode
        //{
         //   return .underline(height: 3, color: UIColor.blue, horizontalPadding: 10, verticalPadding: 0)
        //}
        var focusMode: MenuFocusMode
        {
           return .none
        }
        var itemsOptions: [MenuItemViewCustomizable]
        {
            return [MenuItem1(), MenuItem2(), MenuItem3(), MenuItem4()]
        }
    }
    fileprivate struct MenuItem1: MenuItemViewCustomizable
    {
        var displayMode: MenuItemDisplayMode
        {
            return .text(title: MenuItemText(text: "News"))
        }
    }
    fileprivate struct MenuItem2: MenuItemViewCustomizable
    {
        var displayMode: MenuItemDisplayMode
        {
            let itemText = MenuItemText(text: "Message", color: .lightGray, selectedColor: .white, font: UIFont(name: "Arial", size: 16)!, selectedFont: UIFont(name: "Arial", size: 12)!)
            return .text(title: itemText)
        }
    }
    fileprivate struct MenuItem3: MenuItemViewCustomizable
    {
        var displayMode: MenuItemDisplayMode
        {
            let view = UIView(frame: CGRect(x: 0, y: 0, width: 80, height: 50))
            let label = UILabel(frame: CGRect(x: 0, y: 0, width: 80, height: 50))
            label.textAlignment = .center
            label.text = "Service"
            label.textColor = UIColor.purple
            view.addSubview(label)
            return .custom(view: view)
        }
    }
    fileprivate struct MenuItem4: MenuItemViewCustomizable
    {
        var displayMode: MenuItemDisplayMode
        {
            return .text(title: MenuItemText(text: "Setting"))
        }
    }
}

class SixthViewController: UIViewController,UIViewControllerTransitioningDelegate{
    var imgView: UIImageView = {
        let v = UIImageView(image: UIImage(named:"10.jpg"))
        v.frame = CGRect(x:0.fitScreen, y:80.fitScreen, width:414.fitScreen, height:660.fitScreen)
        return v
    }()
    var imageView : UIImageView!


    var bt : UIButton!
    var transition = BubbleTransition()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        self.title = "日程"
        self.view.backgroundColor = UIColor.white
        self.view.addSubview(imgView)
        self.tabBarItem.image = UIImage(named:"6")
        bt = UIButton(frame: CGRect(x: 180, y: 0, width: 60, height: 60))
        bt.setTitle("我", for: .normal)
        bt.layer.cornerRadius = 30
        bt.backgroundColor = UIColor.lightText
        bt.setTitleColor(UIColor.blue, for:UIControlState())
        bt.titleLabel?.font = UIFont(name: "Arial",size:23)
        bt.layer.masksToBounds = true
        bt.layer.cornerRadius = 16
        bt.layer.borderWidth = 2
        bt.layer.borderColor = UIColor.magenta.cgColor
        bt.alpha = 0.5
        bt.addTarget(self, action: #selector(SixthViewController.popViewController(_:)), for: .touchUpInside)
        self.view.addSubview(bt)
        let options = PagingMenuOptions()
        let pagingMenuController = PagingMenuController(options: options)
        //pagingMenuController.delegate = self
        pagingMenuController.transitioningDelegate = self
        //pagingMenuController.transitioningDelegate = self as? UIViewControllerTransitioningDelegate
        pagingMenuController.view.frame.origin.y += 20
        pagingMenuController.view.frame.size.height -= 20
        
        addChildViewController(pagingMenuController)
        view.addSubview(pagingMenuController.view)
        pagingMenuController.didMove(toParentViewController: self)
        
        ToastView.appearance().backgroundColor = UIColor.white
        ToastView.appearance().textColor = UIColor.cyan
        ToastView.appearance().font = UIFont(name:"Arial",size: 24)
        ToastView.appearance().textInsets = UIEdgeInsets(top:16 ,left:20,bottom:16,right:20)
        ToastView.appearance().cornerRadius = 30
        ToastView.appearance().bottomOffsetPortrait = 380
        Toast(text: "欢迎来到诗意校园,开始你的奇幻校园之旅吧！").show()
    }
   
    @objc func nextPage()
    {
        let viewController = ThirdViewController()
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    @objc func popViewController(_ btn:UIButton)
    {
        let vc = AnimationController()
        vc.transitioningDelegate = self
        vc.modalPresentationStyle = .custom
        self.present(vc, animated: true, completion: nil)
    }
    
    public func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning?
    {
        transition.transitionMode = .present
        transition.startingPoint = bt.center
        transition.bubbleColor = bt.backgroundColor!
        
        return transition
    }
    
    public func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning?
    {
        transition.transitionMode = .dismiss
        transition.startingPoint = bt.center
        transition.bubbleColor = bt.backgroundColor!
        
        return transition
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
}

extension ViewController: UIPageViewControllerDelegate
{
    
    
    func willMove(toMenu menuController: UIViewController, fromMenu previousMenuController: UIViewController)
    {
        print(#function)
        print(previousMenuController)
        print(menuController)
    }
    func didMove(toMenu menuController: UIViewController, fromMenu previousMenuController: UIViewController)
    {
        print(#function)
        print(previousMenuController)
        print(menuController)
    }
    func willMove(toMenuItem menuItemView: MenuItemView, fromMenuItem previousMenuItemView: MenuItemView)
    {
        print(#function)
        print(previousMenuItemView)
        print(menuItemView)
    }
    func didMove(toMenuItem menuItemView: MenuItemView, fromMenuItem previousMenuItemView: MenuItemView)
    {
        print(#function)
        print(previousMenuItemView)
        print(menuItemView)
    }
}

*/
