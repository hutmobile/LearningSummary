//g
//  Created by adong666666 on 2018/5/24.  Copyright © 2018年 adong666666. All rights reserved.

/*
import UIKit
import Toaster
import BubbleTransition

class SixthViewController: UIViewController,UIViewControllerTransitioningDelegate{
    var imgView: UIImageView = {
        let v = UIImageView(image: UIImage(named:"10.jpg"))
        v.frame = CGRect(x:0.fitScreen, y:0.fitScreen, width:414.fitScreen, height:737.fitScreen)
        return v
    }()
    var bt : UIButton!
    var transition = BubbleTransition()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        self.title = "校园"
        self.tabBarItem.image = UIImage(named:"6")
        self.view.addSubview(imgView)
        bt = UIButton(frame: CGRect(x: 180, y: 0, width: 60, height: 60))
        bt.backgroundColor = UIColor.orange
        bt.setTitle("我", for: .normal)
        bt.layer.cornerRadius = 30
        
        bt.addTarget(self, action: #selector(SixthViewController.popViewController(_:)), for: .touchUpInside)
        self.view.addSubview(bt)
        ToastView.appearance().backgroundColor = UIColor.white
        ToastView.appearance().textColor = UIColor.cyan
        ToastView.appearance().font = UIFont(name:"Arial",size: 24)
        ToastView.appearance().textInsets = UIEdgeInsets(top:16 ,left:20,bottom:16,right:20)
        ToastView.appearance().cornerRadius = 30
        ToastView.appearance().bottomOffsetPortrait = 380
        Toast(text: "欢迎来到诗意校园,开始你的奇幻校园之旅吧！").show()
        //self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Next", style: UIBarButtonItemStyle.plain, target: self, action: #selector(SixthViewController.nextPage))
        // let nav = UINavigationController(rootViewController: ThirdViewController())
        //nav.navigationItem.title = "发现"
    }
    @objc func nextPage()
    {
        let viewController = ThirdViewController()
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    @objc func popViewController(_ btn:UIButton)
    {
        let vc = AnimationController()
        vc.transitioningDelegate = self
        vc.modalPresentationStyle = .custom
        self.present(vc, animated: true, completion: nil)
    }
    
    public func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning?
    {
        transition.transitionMode = .present
        transition.startingPoint = bt.center
        transition.bubbleColor = bt.backgroundColor!
        
        return transition
    }
    
    public func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning?
    {
        transition.transitionMode = .dismiss
        transition.startingPoint = bt.center
        transition.bubbleColor = bt.backgroundColor!
        
        return transition
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
}

*/
