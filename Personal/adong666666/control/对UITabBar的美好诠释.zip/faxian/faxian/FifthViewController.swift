//f
//  Created by adong666666 on 2018/5/24. Copyright © 2018年 adong666666. All rights reserved.


import UIKit

class FifthViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        self.title = "我的"
        self.tabBarItem.image = UIImage(named:"7")
        self.view.backgroundColor = UIColor.white  
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    

}
