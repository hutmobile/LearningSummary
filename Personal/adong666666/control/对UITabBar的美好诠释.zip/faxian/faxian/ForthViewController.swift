//e
//  Created by adong666666 on 2018/5/24. Copyright © 2018年 adong666666. All rights reserved.

import UIKit

class ForthViewController: UIViewController {
    var imgView: UIImageView = {
        let v = UIImageView(image: UIImage(named:"11.jpg"))
        v.frame = CGRect(x:0.fitScreen, y:0.fitScreen, width:414.fitScreen, height:737.fitScreen)
        return v
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        self.title = "日程"
        self.tabBarItem.image = UIImage(named:"4")
        self.view.backgroundColor = UIColor.white
        self.view.addSubview(imgView)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }
    

}
