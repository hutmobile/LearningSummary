//g
//  Created by adong666666 on 2018/5/24.  Copyright © 2018年 adong666666. All rights reserved.


import UIKit

class SixthViewController: UIViewController {
    var imgView: UIImageView = {
        let v = UIImageView(image: UIImage(named:"10.jpg"))
        v.frame = CGRect(x:0.fitScreen, y:0.fitScreen, width:414.fitScreen, height:737.fitScreen)
        return v
    }()
        override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        self.title = "校园"
        self.tabBarItem.image = UIImage(named:"6")
        self.view.backgroundColor = UIColor.white
        self.view.addSubview(imgView)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
}

