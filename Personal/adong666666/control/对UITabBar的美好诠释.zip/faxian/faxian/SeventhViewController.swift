//h
//  Created by adong666666 on 2018/5/25.  Copyright © 2018年 adong666666. All rights reserved.


import UIKit

class SeventhViewController: UIViewController {
    var imgView: UIImageView = {
        let v = UIImageView(image: UIImage(named:"5.jpg"))
        v.frame = CGRect(x:0.fitScreen, y:0.fitScreen, width:414.fitScreen, height:737.fitScreen)
        return v
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(imgView)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    



}
