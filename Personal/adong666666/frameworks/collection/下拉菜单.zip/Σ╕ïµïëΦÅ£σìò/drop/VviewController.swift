import UIKit

class ViewController: UIViewController {
    
    lazy var levelArr: Array<Any>? = {
        return ["全部","三甲医院","三乙医院","二甲医院","二乙医院","门诊","民营医院","体检机构","私营企业","ewrwrq","dsfdj","dsjflj"]
    }()
    
    lazy var menu: Menu = {
        var me = Menu.initMenu(size: CGSize(width:UIScreen.main.bounds.size.width ,height:self.view.frame.size.height / 2
        ))
        self.view.addSubview(me)
        return me
    }()
    
    
    /**
     菜单的弹出 和 收回
     */
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.backgroundColor = UIColor.cyan
        if self.menu.isShow! == false {
            
            let point = CGPoint(x:0,y: 100)
            self.menu.popupMenu(orginPoint:point, arr: self.levelArr!)
            
            self.menu.didSelectIndex = { [unowned self] (index:Int) in
                
                print( "选中--  \(index) -行 -- \(String(describing: self.levelArr?[index]))")
            }
        }else{
            
            self.menu.packUpMenu()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    

}
