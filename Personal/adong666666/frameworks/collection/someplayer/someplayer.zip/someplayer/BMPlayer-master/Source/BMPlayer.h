//
//  BMPlayer.h
//  BMPlayer
//
//  Created by BrikerMan on 2016/12/2.
//  Copyright © 2016年 BrikerMan. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BMPlayer.
FOUNDATION_EXPORT double BMPlayerVersionNumber;

//! Project version string for BMPlayer.
FOUNDATION_EXPORT const unsigned char BMPlayerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BMPlayer/PublicHeader.h>

