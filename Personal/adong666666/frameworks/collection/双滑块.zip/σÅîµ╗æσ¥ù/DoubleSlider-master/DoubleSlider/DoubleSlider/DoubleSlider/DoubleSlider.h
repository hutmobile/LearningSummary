//
//  DoubleSlider.h
//  DoubleSlider
//
//  Created by josh on 2018/04/02.
//  Copyright © 2018年 yhkaplan. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DoubleSlider.
FOUNDATION_EXPORT double DoubleSliderVersionNumber;

//! Project version string for DoubleSlider.
FOUNDATION_EXPORT const unsigned char DoubleSliderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DoubleSlider/PublicHeader.h>


