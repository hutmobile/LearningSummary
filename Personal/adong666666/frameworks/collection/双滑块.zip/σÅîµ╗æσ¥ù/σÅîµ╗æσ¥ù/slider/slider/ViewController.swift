
import UIKit

public extension Double {
    var fitScreen: Double {
        return self/414.0 * Double(UIScreen.main.bounds.size.width)
    }
}
public extension Double {
    var fitHeight: Double {
        return self/737.0 * Double(UIScreen.main.bounds.size.height)
    }
}


class ViewController: UIViewController {

    var indicatorSlider: AORangeSlider = {
        let iindicatorSlider = AORangeSlider()
        iindicatorSlider.frame = CGRect(x:7.fitScreen, y:220.fitHeight, width: 400.fitScreen, height: 60.fitHeight)
        iindicatorSlider.isUserInteractionEnabled = true
        return iindicatorSlider
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(indicatorSlider)
        setupIndicatorSlider()
    }


}

extension ViewController{
    func setupIndicatorSlider() {
        
        let contentView = indicatorSlider//.superview!
        
        indicatorSlider.minimumValue = 0
        indicatorSlider.maximumValue = 100
        indicatorSlider.lowValue = 0
        indicatorSlider.highValue = 100
        indicatorSlider.minimumDistance = 20
        
        let lowLabel = UILabel()
        contentView.addSubview(lowLabel)
        lowLabel.textAlignment = .center
        lowLabel.frame = CGRect(x:0.fitScreen, y:0.fitHeight, width: 60.fitScreen, height: 20.fitHeight)
        
        let highLabel = UILabel()
        contentView.addSubview(highLabel)
        highLabel.textAlignment = .center
        highLabel.frame = CGRect(x: 0.fitScreen, y: 0.fitHeight, width: 60.fitScreen, height: 20.fitHeight)
        
        indicatorSlider.valuesChangedHandler = { [weak self] in
            guard let `self` = self else {
                return
            }
            let lowCenterInSlider = CGPoint(x:self.indicatorSlider.lowCenter.x, y: self.indicatorSlider.lowCenter.y - 30)
            let highCenterInSlider = CGPoint(x:self.indicatorSlider.highCenter.x, y: self.indicatorSlider.highCenter.y - 30)
            let lowCenterInView = self.indicatorSlider.convert(lowCenterInSlider, to: contentView)
            let highCenterInView = self.indicatorSlider.convert(highCenterInSlider, to: contentView)
            
            lowLabel.center = lowCenterInView
            highLabel.center = highCenterInView
            lowLabel.text = String(format: "%.1f", self.indicatorSlider.lowValue)
            highLabel.text = String(format: "%.1f", self.indicatorSlider.highValue)
        }
    }
}
