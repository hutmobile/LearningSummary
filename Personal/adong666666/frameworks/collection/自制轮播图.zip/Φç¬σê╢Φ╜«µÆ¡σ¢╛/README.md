# CyclicBanner
A CyclicBanner Demo 一个图片无限轮播Demo，使用Swift3.0，一种使用UIScrollView，一种使用UICollectionView
效果如下
![](https://github.com/CoderTian/CyclicBanner/blob/master/images/main.gif?raw=true)
