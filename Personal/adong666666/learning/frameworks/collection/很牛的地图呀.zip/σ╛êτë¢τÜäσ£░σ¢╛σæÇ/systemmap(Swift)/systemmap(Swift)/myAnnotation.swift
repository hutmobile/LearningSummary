//
//  myAnnotation.swift
//  systemmap(Swift)
//
//  Created by anan on 2017/8/1.
//  Copyright © 2017年 Plan. All rights reserved.
//

import UIKit
import MapKit
class myAnnotation: NSObject{
    
    var coordinate = CLLocationCoordinate2D()
    var title = NSString()
    var subtitle = NSString()

}
