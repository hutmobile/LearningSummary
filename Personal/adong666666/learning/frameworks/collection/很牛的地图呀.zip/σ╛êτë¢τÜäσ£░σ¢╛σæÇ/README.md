# iOS-map1
iOS系统高德地图的一般使用



#点击右上角的 star、watch 按钮，可以收藏本仓库，看到本仓库的更新！

    1.地图（MKMapView）的使用

    2.定位（CLLocationManager）的使用

    3.自定义大头针

    4.路线规划，画线

    5.跳转第三方地图导航

    6.地理编码和反地理编码（CLGeocoder）的使用

在开发过程中，如有问题请与我联系。

邮箱：peiliancoding@gmail.com

QQ ：2877025939
