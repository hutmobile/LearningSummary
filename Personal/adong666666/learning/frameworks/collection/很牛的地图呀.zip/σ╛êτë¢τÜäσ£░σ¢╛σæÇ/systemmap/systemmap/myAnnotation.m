//
//  myAnnotationView.m
//  系统高德地图
//
//  Created by anan on 2017/7/5.
//  Copyright © 2017年 Plan. All rights reserved.
//

#import "myAnnotation.h"

@implementation myAnnotation

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
