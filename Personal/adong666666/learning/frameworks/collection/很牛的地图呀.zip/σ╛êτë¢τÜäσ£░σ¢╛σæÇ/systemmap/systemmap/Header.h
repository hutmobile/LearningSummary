//
//  Header.h
//  系统高德地图
//
//  Created by anan on 2017/7/5.
//  Copyright © 2017年 Plan. All rights reserved.
//

#ifndef Header_h
#define Header_h


#ifndef __OPTIMIZE__
#define NSLog(...) NSLog(__VA_ARGS__)
#else
#define NSLog(...) {}
#endif

#endif /* Header_h */
