---
title: Mac系统 利用github+hexo 搭建自己的Blog
tags: 
- 博客
---
# 环境配置
## 1.Git
用来将本地Hexo内容提交到Github上。Xcode自带Git。
## 2.Node.js
用来生成静态页面。[Node.js官网](https://nodejs.org/en/download/)。 下载下图红色箭头所指向的文件！![](https://upload-images.jianshu.io/upload_images/13179799-2bf72161dcd8dfe7.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
![](https://upload-images.jianshu.io/upload_images/13179799-ebbfca5e3b697d2e.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240) 最后一路按照即可！
# 安装hexo 
打开终端执行以下命令
> $ sudo npm install -g hexo  

执行该命令后hexo即安装完成
# 初始化
在桌面创建一个名为hexo的文件夹 然后终端进入到该文件夹执行如下命令：
> $ hexo init

然后执行如下命令打开hexo 服务器
> $ hexo s

打开http://localhost:4000 , 能看到如下界面 ![](https://upload-images.jianshu.io/upload_images/13179799-e814287874919b62.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

本地搭建完成，下面关联Github
# 关联Github
## 1.登录Github
登陆你的GitHub，新建仓库，名为用户名.github.io固定写法。如下图所示：![](https://upload-images.jianshu.io/upload_images/13179799-2a63e9ea44cd6d28.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
本地内容如下:![](https://upload-images.jianshu.io/upload_images/13179799-457d98575321f4ae.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
 终端cd到本地 hexo 文件夹下，打开文件夹下 _config.yml 文件，终端输入命令：
> $ vim _config.yml

打开之后往下滑到最后修改成如下样子：![](https://upload-images.jianshu.io/upload_images/13179799-86b622bab7259975.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
把红框内容改成自己的github用户名即可

接下来执行如下命令： 
> $ hexo g 

若出现找不到博客错误则执行:
> $ npm install hexo --save

在执行如下命令
> $ hexo d

若出现无法连接git或找不到git，则执行如下命令来安装：
>  $ npm install hexo-deployer-git --save  

若你未关联Github，则执行hexo deploy命令时终端会提示你输入Github的用户名和密码，即
> Username for 'https://github.com':
  Password for 'https://github.com':

hexo d 命令成功后 打开：http://zhangchione.github.io 将zhangchione改成你的 用户名即可。和之前打开的一样。

本地和git关联成功 
## 属于自己的博客搭建成功！！
