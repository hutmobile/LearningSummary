//
//  ViewController.swift
//  DemoApp
//
//  Created by Jerry on 17/9/19.
//  Copyright © 2017 www.coolketang.com. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let lable = UILabel(frame: CGRect(x: 0 , y: 0, width: 200, height: 40))
        lable.center = self.view.center
        lable.textAlignment = NSTextAlignment.center
        lable.adjustsFontSizeToFitWidth = true
        lable.text = "ABCDEFG"
        lable.textColor = UIColor.black
        self.view.addSubview(lable)
        
        let lable1 = UILabel(frame: CGRect(x: 0 , y: 60, width: 200, height: 40))
        lable1.center = CGPoint(x:lable.center.x, y:lable.center.y+30)
        lable1.textAlignment = NSTextAlignment.center
        lable1.adjustsFontSizeToFitWidth = true
        
        lable1.font = UIFont(name: "AiDeep", size: 32)
        lable1.text = "ABCDEFG"
        lable1.textColor = UIColor.black
        self.view.addSubview(lable1)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
